package utils;

import java.time.Instant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TripEvent extends Event {
  public final String CpuInfo;
  

  private static final Logger LOG = LoggerFactory.getLogger(TripEvent.class);

  public TripEvent() {
    CpuInfo = "0";
  }


  public String getCpuInfo() {
	return CpuInfo;
}


@Override
  public String toString() {
    return "SearchResult{" +
            "CPu=" + CpuInfo +
            '}';
  }


@Override
public long getTimestamp() {
	// TODO Auto-generated method stub
	return 0;
}
}