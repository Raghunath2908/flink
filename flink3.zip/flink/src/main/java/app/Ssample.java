package app;

import java.util.Properties;

import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkFunction;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.apache.flink.streaming.connectors.elasticsearch.util.RetryRejectedExecutionFailureHandler;
import org.apache.flink.streaming.connectors.elasticsearch6.ElasticsearchSink;
import org.apache.flink.streaming.connectors.kinesis.FlinkKinesisConsumer;
import org.apache.flink.streaming.connectors.kinesis.config.AWSConfigConstants;
import org.apache.flink.streaming.connectors.kinesis.config.ConsumerConfigConstants;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.Requests;
import org.elasticsearch.common.xcontent.XContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import utils.AmazonElasticsearchSink;
import utils.TripEvent;
import utils.Event;

public class Ssample {
	private static final Logger LOG = LoggerFactory.getLogger(Ssample.class);

	private static final String DEFAULT_REGION_NAME = "eu-central-1";
	

	public static void main(String[] args) throws Exception {

		ParameterTool parameter = ParameterToolUtils.fromArgsAndApplicationProperties(args);

		// set up the streaming execution environment
		final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

		DataStream<TripEvent> events;

		if (parameter.has("InputKinesisStream")
				&& (parameter.has("InputKafkaBootstrapServers") || parameter.has("InputKafkaTopic"))) {
			throw new RuntimeException(
					"You can only specify a single source, either a Kinesis data stream or a Kafka topic");
		} else if (parameter.has("InputKinesisStream")) {
			LOG.info("Reading from {} Kinesis stream", parameter.get("InputKinesisStream"));
			events = env.addSource(getKinesisSource(parameter)).name("Kinesis source");

		} else {
			throw new RuntimeException(
					"Missing runtime parameters: Specify 'InputKinesisStreamName' xor ('InputKafkaBootstrapServers' and 'InputKafkaTopic') as a parameters to the Flink job");
		}

		if (parameter.has("OutputElasticsearchEndpoint")) {
			LOG.info("Writing to {} ES endpoint", parameter.has("OutputElasticsearchEndpoint"));

			events.addSink(getElasticsearchSink(parameter)).name("Elasticsearch sink");
		}

		env.execute();
	}

	private static SourceFunction<TripEvent> getKinesisSource(ParameterTool parameter) {
		String streamName = parameter.getRequired("InputKinesisStream");
		String region = parameter.get("InputStreamRegion", DEFAULT_REGION_NAME);
		String initialPosition = parameter.get("InputStreamInitalPosition",
				ConsumerConfigConstants.DEFAULT_STREAM_INITIAL_POSITION);

		// set Kinesis consumer properties
		Properties kinesisConsumerConfig = new Properties();
		// set the region the Kinesis stream is located in
		kinesisConsumerConfig.setProperty(AWSConfigConstants.AWS_REGION, region);
		// obtain credentials through the DefaultCredentialsProviderChain, which
		// includes the instance metadata
		kinesisConsumerConfig.setProperty(AWSConfigConstants.AWS_CREDENTIALS_PROVIDER, "AUTO");
		// poll new events from the Kinesis stream once every second
		kinesisConsumerConfig.setProperty(ConsumerConfigConstants.SHARD_GETRECORDS_INTERVAL_MILLIS, "1000");

		kinesisConsumerConfig.setProperty(ConsumerConfigConstants.STREAM_INITIAL_POSITION, initialPosition);

		return new FlinkKinesisConsumer(streamName, (DeserializationSchema) new TripEvent(), kinesisConsumerConfig);
	}

	private static ElasticsearchSink<TripEvent> getElasticsearchSink(ParameterTool parameter) {
		String elasticsearchEndpoint = parameter.getRequired("ElasticSearchEndpoint");
		String region = parameter.get("ElasticsearchRegion", DEFAULT_REGION_NAME);

		ElasticsearchSink.Builder<TripEvent> builder = AmazonElasticsearchSink
				.elasticsearchSinkBuilder(elasticsearchEndpoint, region, new ElasticsearchSinkFunction<TripEvent>() {
					IndexRequest createIndexRequest(TripEvent element) {
						String type = "sampletype";
						String cpuinfo = element.getCpuInfo();

						return Requests.indexRequest().index(type).type(type).id(cpuinfo)
								.source(TripEvent.parseEvent("dummy".getBytes()), XContentType.JSON);
					}

					@Override
					public void process(TripEvent element, RuntimeContext ctx, RequestIndexer indexer) {
						indexer.add(createIndexRequest(element));
					}
				});

		builder.setFailureHandler(new RetryRejectedExecutionFailureHandler());

		if (parameter.has("ElasticsearchBulkFlushMaxSizeMb")) {
			builder.setBulkFlushMaxSizeMb(parameter.getInt("ElasticsearchBulkFlushMaxSizeMb"));
		}

		if (parameter.has("ElasticsearchBulkFlushMaxActions")) {
			builder.setBulkFlushMaxActions(parameter.getInt("ElasticsearchBulkFlushMaxActions"));
		}

		if (parameter.has("ElasticsearchBulkFlushInterval")) {
			builder.setBulkFlushInterval(parameter.getLong("ElasticsearchBulkFlushInterval"));
		}

		return builder.build();
	}
}