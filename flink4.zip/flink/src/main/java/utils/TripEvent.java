package utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TripEvent {
  public final String CpuInfo;
  private static final Logger LOG = LoggerFactory.getLogger(TripEvent.class);

  public TripEvent(String cpuinfo) {
    this.CpuInfo = cpuinfo;
  }


  public String getCpuInfo() {
	return CpuInfo;
}


@Override
  public String toString() {
    return "searchResult{" +
            "CPu=" + CpuInfo +
            '}';
  }


public static Object parseEvent(byte[] bytes) {
	// TODO Auto-generated method stub
	return "hi";
}

}