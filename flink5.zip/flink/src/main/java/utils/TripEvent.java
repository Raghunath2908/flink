package utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;


public class TripEvent {
  public final String CpuInfo;
  private static final Logger LOG = LoggerFactory.getLogger(TripEvent.class);
  
  
  public static TripEvent deserialise(byte[] streamName) {
		String sName = "" + streamName;
		Gson gs = new Gson();
		return gs.fromJson(sName, TripEvent.class);
	}

  public TripEvent(String cpuinfo) {
    this.CpuInfo = cpuinfo;
  }


  public String getCpuInfo() {
	return CpuInfo;
}


@Override
  public String toString() {
    return "searchResult{" +
            "CPu=" + CpuInfo +
            '}';
  }


public static Object parseEvent(byte[] bytes) {
	// TODO Auto-generated method stub
	return "hi";
}

}